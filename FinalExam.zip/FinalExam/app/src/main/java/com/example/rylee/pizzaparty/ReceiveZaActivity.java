package com.example.rylee.pizzaparty;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class ReceiveZaActivity extends Activity {

    private String pizzaType;
    private String pizzaTypeURL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receive_za);

        Intent intent = getIntent();
        pizzaType = intent.getStringExtra("pizzaType");
        pizzaTypeURL = intent.getStringExtra("pizzaTypeURL");
        Log.i("type received", pizzaType);
        Log.i("url received", pizzaTypeURL);

        TextView messageView = findViewById(R.id.YourPizzaText);
        messageView.setText(pizzaType);

        final ImageButton imageButton = findViewById(R.id.imageButton);
        View.OnClickListener buttonClick = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadWeb(view);
            }
        };

        //add listener to the button
        imageButton.setOnClickListener(buttonClick);

    }

    public void loadWeb(View view){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(pizzaTypeURL));
        startActivity(intent);
    }
    }
