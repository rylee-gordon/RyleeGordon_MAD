package com.example.rylee.pizzaparty;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends Activity {

    //Ref Custom Class
    private PizzaType myPizza = new PizzaType ();
    private TextView pizzaText;
    private String message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        pizzaText = findViewById(R.id.PizzaTextView);

        if(savedInstanceState !=null) {
            message = savedInstanceState.getString("msg");

            pizzaText.setText(message);
        }


        //Get the button
        final Button button = findViewById(R.id.button);

        //Create a button listener
        View.OnClickListener onclick = new View.OnClickListener() {
            public void onClick(View view) { Pizza (view);
            }
        };

        //Add listener to pizza button
        button.setOnClickListener(onclick);
    }

    public void Pizza(View view) {


        //Toggle Button
        ToggleButton toggle = findViewById(R.id.toggleButton);
        boolean location = toggle.isChecked();

        //Spinner
        Spinner size = findViewById(R.id.spinner);
        String pizzaSize = String.valueOf(size.getSelectedItem());

        //Spinner Position
        Integer sizes = size.getSelectedItemPosition();

        //Radio
        RadioGroup crust = findViewById(R.id.radioGroup);
        int crust_id = crust.getCheckedRadioButtonId();

        //Check Boxes meat vs. veggie
        CheckBox meatTopping = findViewById(R.id.checkBox);
        boolean meat = meatTopping.isChecked();

        CheckBox veggieTopping = findViewById(R.id.checkBox2);
        boolean veggie = veggieTopping.isChecked();

        String yourPizza;

        if (crust_id == R.id.radioButton){
            switch (pizzaSize) {
                case "Small":
                yourPizza = "small size pizza with red sauce";
                break;

                case "Medium":
                yourPizza = "medium size pizza with red sauce";
                break;

                case "Large":
                yourPizza = "large size pizza with red sauce";
                break;
            }
        }else{
            switch (pizzaSize) {
                case "Small":
                    yourPizza = "small size pizza with white sauce";
                    break;

                case "Medium":
                    yourPizza = "medium size pizza with white sauce";
                    break;

                case "Large":
                    yourPizza = "large size pizza with white sauce";
                    break;
            }

        }

        Log.d( "MSG",  "pizzaDesc");
        pizzaText = findViewById(R.id.PizzaTextView);
        EditText name = findViewById(R.id.editText);
        String nameValue = name.getText().toString();
        message = nameValue + "is a" + crust_id + "with" ;
        Log.d( "VAR", nameValue);
        pizzaText.setText(message);


        //Make a TOAST
        if (crust_id == -1){
            Context context = getApplicationContext();
            CharSequence text = "Please choose a type of crust.";
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }

        //suggested pizza place
        String suggestedPizzaType = myPizza.getPizzaType();

        //URL of pizza place
        String suggestedPizzaTypeURL = myPizza.getPizzaTypeURL();
        Log.i("type", suggestedPizzaType);
        Log.i("url", suggestedPizzaTypeURL);

        //create an intent
        Intent intent = new Intent(this, ReceiveZaActivity.class);
        intent.putExtra("pizzaType", suggestedPizzaType);
        intent.putExtra("pizzaURL", suggestedPizzaTypeURL);

        //start the intent
        startActivity(intent);
    }
}
