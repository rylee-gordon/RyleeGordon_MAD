package com.example.rylee.pizzaparty;

public class PizzaType {
    private String pizzaType;
    private String pizzaTypeURL;

    private void setPizza(Integer pizzaPlace) {
        switch (pizzaPlace) {
            case 0://Thin Crust
                pizzaType = " Pizzeria Locale";
                pizzaTypeURL = "https://localeboulder.com/";
                break;
            case 1://Thick Crust
                pizzaType = "Backcountry Pizza";
                pizzaTypeURL = "";
                break;
            case 2://Gluten free
                pizzaType = "Boss Lady";
                pizzaTypeURL = "https://bossladypizza.com/";
                break;
            default:
                pizzaType = "none";
                pizzaTypeURL = "https://www.google.com/search?q=pizza+places+in+boulder&rlz=1C5CHFA_enUS762US762&oq=pizza+places+in+bo&aqs=chrome.0.0j69i57j0l4.8558j0j7&sourceid=chrome&ie=UTF-8";
        }

    }

    public void setPizzaType(Integer pizzaPizza) {
        setPizza(pizzaPizza);
    }

    public void setPizzaTypeURL(Integer pizzaPizza) {
        setPizza(pizzaPizza);
    }

    public String getPizzaType() {
        return pizzaType;
    }

    public String getPizzaTypeURL() {
        return pizzaTypeURL;
    }
}
