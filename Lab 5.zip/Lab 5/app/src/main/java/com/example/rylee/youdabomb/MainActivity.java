package com.example.rylee.youdabomb;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void sayBomb(View view) {
        TextView bombText=findViewById(R.id.message);
        EditText name = findViewById(R.id.editText);
        String nameValue = name.getText().toString();
        bombText.setText("You Da Bomb "+nameValue+"!");
        ImageView bomb = findViewById(R.id.imageView);
        bomb.setImageResource(R.drawable.bomb);
    }
}
