package com.example.rylee.grinningskin;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void findProduct(View view) {
        ToggleButton toggle = findViewById(R.id.toggleButton);
        boolean location = toggle.isChecked();

        //Spinner
        Spinner product = findViewById(R.id.spinner);
        String productType = String.valueOf(product.getSelectedItem());

        //Radio
        RadioGroup skinType = findViewById(R.id.radioGroup);
        int skinType_id = skinType.getCheckedRadioButtonId();

        //check boxes
        CheckBox floralCheckBox = findViewById(R.id.checkBox1);
        boolean floral = floralCheckBox.isChecked();

        CheckBox cleanCheckBox = findViewById(R.id.checkBox2);
        boolean clean = cleanCheckBox.isChecked();

        String perfectProduct;

        if (skinType_id == R.id.radioButton1) { //inside
            // DRY SKIN, DRUGSTORE
            switch (productType) {
                case "Facewash":
                    perfectProduct = "Burt’s Bees Cleansing Oil";
                    break;
                case "Toner":
                    perfectProduct = "Thayer's Witch Hazel Alcohol Free Toner";
                    break;
                case "Moisturizer":
                    perfectProduct = "Simple Hydrating Gel Cream";
                    break;
                default:
                    perfectProduct = "Water";
            }
        } else { //outside
            // OILY SKIN, DRUGSTORE
            switch (productType) {
                case "Facewash":
                    perfectProduct = "Alba Botanica Good & Clean Gentle Acne Wash";
                    break;
                case "Toner":
                    perfectProduct = "Simple Soothing Facial Toner";
                    break;
                case "Moisturizer":
                    perfectProduct = "Clean & Clear Advantage Acne Control Moisturizer";
                    break;
                default:
                    perfectProduct = "Water";
            }
        }

        //Check Radio Buttons
        if (skinType_id == -1) {
            //toast!
            Context context = getApplicationContext();
            CharSequence text = "Please choose your skin type.";
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        } else {
            if (location) {
                // DRY SKIN, HIGH END
                if (skinType_id == R.id.radioButton1) {
                    switch (productType) {
                        case "Facewash":
                            perfectProduct = "Eve Lom Gel Balm Cleanser";
                            break;
                        case "Toner":
                            perfectProduct = "FRESH Rose Deep Hydration Facial Toner";
                            break;
                        case "Moisturizer":
                            perfectProduct = "TATCHA The Silk Cream";
                            break;
                        default:
                            perfectProduct = "Water";
                    }
                }
                // OILY SKIN, HIGH END
                else {
                    switch (productType) {
                        case "Facewash":
                            perfectProduct = "TATCHA The Deep Cleanse";
                            break;
                        case "Toner":
                            perfectProduct = "LA MER The Tonic";
                            break;
                        case "Moisturizer":
                            perfectProduct = "Drunk Elephant Protini Polypeptide Cream";
                            break;
                        default:
                            perfectProduct = "Water";
                    }
                }
            } else { //outside
                if (skinType_id == R.id.radioButton2) {
                    if (floral) {
                        perfectProduct = "FRESH Floaral all-in-one";

                    }
                } else {
                    productType = "Clinique all-in-one";
                }
            }
        }


       TextView productSelection = findViewById(R.id.productTextView);
       productSelection.setText("Your Perfect Product: \n" + perfectProduct);
   }
}
