package com.example.rylee.moodanimal;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button redButton;
    private Button purpleButton;
    private Button orangeButton;
    private Button blueButton;
    private Button yellowButton;
    private Button brownButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //red button opens bull activity
        redButton = (Button) findViewById(R.id.button);
        redButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openBullActivity();
            }
        });

        //purple button opens owl activity
        purpleButton = (Button) findViewById(R.id.button2);
        purpleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openOwlActivity();
            }
        });

        //orange button opens fox activity
        orangeButton = (Button) findViewById(R.id.button3);
        orangeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFoxActivity();
            }
        });

        //blue button opens wolf activity
        blueButton = (Button) findViewById(R.id.button4);
        blueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openWolfActivity();
            }
        });

        //yellow button opens tiger activity
        yellowButton = (Button) findViewById(R.id.button5);
        yellowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openTigerActivity();
            }
        });
        //brown button opens bear activity
        brownButton = (Button) findViewById(R.id.button6);
        brownButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openBearActivity();
            }
        });
    }

    //openBullActivity Intent
    public void openBullActivity(){
        Intent intent = new Intent(this, BullActivity.class);
        startActivity(intent);
    }

    //openOwlActivity Intent
    public void openOwlActivity(){
        Intent intent = new Intent(this, OwlActivity.class);
        startActivity(intent);
    }

    //openFoxActivity Intent
    public void openFoxActivity() {
        Intent intent = new Intent(this, FoxActivity.class);
        startActivity(intent);
    }

    //openWolfActivity Intent
    public void openWolfActivity() {
        Intent intent = new Intent(this, WolfActivity.class);
        startActivity(intent);
    }

    //openTigerActivity Intent
    public void openTigerActivity() {
        Intent intent = new Intent(this, TigerActivity.class);
        startActivity(intent);
    }

    //openBearActivity Intent
    public void openBearActivity() {
        Intent intent = new Intent(this, BearActivity.class);
        startActivity(intent);
    }
}
