package com.example.rylee.winetime;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class ReceiveWineActivity extends Activity {

    private String wineFlavor;
    private String wineFlavorURL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receive_wine);

        Intent intent = getIntent();
        wineFlavor = intent.getStringExtra("wineName");
        wineFlavorURL = intent.getStringExtra("wineURL");
        Log.i("flavor received", wineFlavor);
        Log.i("url received", wineFlavorURL);

        TextView messageView = findViewById(R.id.wineFlavorTextView);
        messageView.setText("You should definitely try " + wineFlavor);

        final ImageButton imageButton = findViewById(R.id.imageButton);
        View.OnClickListener imgbuttonclick = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadWebSite(view);
            }
        };

        //add listener to the button
        imageButton.setOnClickListener(imgbuttonclick);

    }

    public void loadWebSite(View view){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(wineFlavorURL));
        startActivity(intent);
    }
}
