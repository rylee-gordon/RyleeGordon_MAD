package com.example.rylee.winetime;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {

    private WineFlavor myWine = new WineFlavor ();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //get button
        final Button button = findViewById(R.id.button);

        //create listener
        View.OnClickListener onclick = new View.OnClickListener() {
            public void onClick(View view) {
                findWine(view);
            }
        };

        //add listener to the button
        button.setOnClickListener(onclick);
    }

    public void findWine (View view) {

        //get spinner
        Spinner flavorsSpinner = findViewById(R.id.spinner);

        //get spinner item array position
        Integer flavors = flavorsSpinner.getSelectedItemPosition();

        //set the coffee shop
        myWine.setWineFlavor(flavors);

        //get suggested coffee shop
        String suggestedWineFlavor = myWine.getWineFlavor();

        //get URL of suggested coffee shop
        String suggestedWineFlavorURL = myWine.getWineFlavorURL();
        Log.i("flavor", suggestedWineFlavor);
        Log.i("url", suggestedWineFlavorURL);

        //create an intent
        Intent intent = new Intent(this, ReceiveWineActivity.class);
        intent.putExtra("wineName", suggestedWineFlavor);
        intent.putExtra("wineURL", suggestedWineFlavorURL);

        //start the intent
        startActivity(intent);
    }
}
