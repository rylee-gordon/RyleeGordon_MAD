package com.example.rylee.winetime;

public class WineFlavor {
    private String wineFlavor;
    private String wineFlavorURL;

    private void setWineInfo(Integer coffeecrowd){
        switch (coffeecrowd) {
            case 0: //fruity
                wineFlavor = "Moscato";
                wineFlavorURL = "https://www.totalwine.com/wine/red-wine/merlot/yellow-tail-merlot/p/93660015?s=2301&igrules=true";
                break;
            case 1: //fresh
                wineFlavor = "Pinot Noir";
                wineFlavorURL = "https://www.totalwine.com/wine/red-wine/pinot-noir/complicated-pinot-noir-sonoma-county/p/143748750";
                break;
            case 2: //zesty
                wineFlavor = "Zinfandel";
                wineFlavorURL = "https://www.totalwine.com/wine/red-wine/zinfandel/macchia-zinfandel-adventurous/p/105075750?s=2301&igrules=true";
                break;
            case 3: //buttery
                wineFlavor = "Chardonnay";
                wineFlavorURL = "https://www.totalwine.com/wine/white-wine/chardonnay/barefoot-cellars-chardonnay/p/98602015?s=2301&igrules=true";
                break;
            case 4: //dry
                wineFlavor = "Sauvignon Blanc";
                wineFlavorURL = "https://www.totalwine.com/wine/new-arrivals/white-wine/sauvignon-blanc/giant-sky-marlborough-sauv-blanc/p/171347750?s=2301&igrules=true";
                break;
            default:
                wineFlavor = "none";
                wineFlavorURL = "https://www.totalwine.com/";
        }
    }

    public void setWineFlavor(Integer flavorWine){
        setWineInfo(flavorWine);
    }
    public void setWineFlavorURL(Integer flavorWine){
        setWineInfo(flavorWine);
    }
    public String getWineFlavor(){
        return wineFlavor;
    }
    public String getWineFlavorURL(){
        return wineFlavorURL;
    }
}
